function [] = fr_fwd_relative_time_stamps()
% fr_fwd_relative_time_stamps    

% Author: Ariel Tankus.
% Created: 30.12.2008.


