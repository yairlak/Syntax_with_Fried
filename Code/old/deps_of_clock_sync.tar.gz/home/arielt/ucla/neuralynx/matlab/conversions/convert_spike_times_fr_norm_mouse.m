function [] = convert_spike_times_fr_norm_mouse()
% convert_spike_times_fr_norm_mouse    

% Author: Ariel Tankus.
% Created: 24.07.2005.


convert_spikes_to_spike_times;
convert_spikes_fr_norm_mouse;
