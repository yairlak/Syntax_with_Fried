function use_abs = use_abs_cheetah_time()
% use_abs_cheetah_time    

% Author: Ariel Tankus.
% Created: 09.08.2009.


use_abs = true;
