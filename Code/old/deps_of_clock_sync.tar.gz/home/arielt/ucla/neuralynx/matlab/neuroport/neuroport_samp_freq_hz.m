function freq_hz = neuroport_samp_freq()
% neuroport_samp_freq    

% Author: Ariel Tankus.
% Created: 26.01.2010.


freq_hz = 30000;