function [] = process_mouse_and_spike_times()
% process_mouse_and_spike_times    

% Author: Ariel Tankus.
% Created: 14.08.2005.


process_spike_times;
convert_spike_times_fr_norm_mouse;
