function [] = manual_fix_neuralynx(filename)
% manual_fix_neuralynx    

% Author: Ariel Tankus.
% Created: 30.03.2017.


load ./manual_time_stamps_neuralynx.txt;

load cheetah_event_times_bit0.log;

